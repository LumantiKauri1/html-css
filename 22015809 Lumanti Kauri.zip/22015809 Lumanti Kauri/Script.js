
// Js for function on each buy and add to cart button
function register(){
    alert('You need to Register in order to proceed.');
    window.location.href = './registration.html';
}